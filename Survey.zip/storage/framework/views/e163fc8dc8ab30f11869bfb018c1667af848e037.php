<script type="text/javascript" src="<?php echo e(url('/')); ?>/assets/scripts/main.js"></script>
<script type="text/javascript" src="<?php echo e(url('/')); ?>/assets/scripts/repeater.js"></script>
<?php /**PATH D:\CODE\Survey\resources\views/layouts/script.blade.php ENDPATH**/ ?>