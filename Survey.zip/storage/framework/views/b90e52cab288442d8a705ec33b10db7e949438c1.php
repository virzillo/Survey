<?php $__env->startSection('content'); ?>
<div class="app-main__outer">
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="pe-7s-car icon-gradient bg-mean-fruit">
                        </i>
                    </div>
                    <div> <?php echo e($survey->titolo); ?>

                        <div class="page-title-subheading"><?php echo e($survey->descrizione); ?></div>
                    </div>
                </div>

            </div>
        </div>

        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="mb-3 card">
                    <div class="card-header-tab card-header-tab-animation card-header">
                        <div class="card-header-title">
                            <i class="header-icon lnr-apartment icon-gradient bg-love-kiss"> </i>

                        </div>
                    </div>
                    <?php if(isset($questions)): ?>
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-body"><h5 class="card-title">Domanda <?php echo e($question->id); ?></h5>
                        <form method="POST" action="">

                            <?php echo csrf_field(); ?>
                            <input name="survey_id" id=""  type="hidden" class="form-control" value=" <?php echo e($survey->id); ?>">
                            <input name="id" id=""  type="hidden" class="form-control" value=" <?php echo e($question->id); ?>">

                            <div class="form-row">
                                <div class="col-md-12">
                                    <div class="position-relative form-group"><label for="" class="">Titolo</label>
                                        <input name="titolo" id="" placeholder="" type="text" class="form-control" value="<?php echo e($question->titolo); ?>"></div>
                                </div>
                            </div>
                            <div class="form-row">

                                <div class="col-md-10">
                                    <div class="position-relative form-group"><label for="" class="">Suggerimento</label>
                                        <input name="descrizione" id="" placeholder=" " type="text" class="form-control" value="<?php echo e($question->descrizione); ?>"></div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <label for="examplePassword"
                                            class="">Tipo risposta</label>
                                            <select class="form-control kt-select2 select2" id="kt_select2_1" name="tipo">

                                                <?php if($question->tipo=='checkbox'): ?>
                                                <option value="checkbox">risposta multipla</option>
                                                <option value="radiobutton">risposta singola</option>
                                                <?php else: ?>
                                                <option value="radiobutton">risposta singola</option>
                                                <option value="checkbox">risposta multipla</option>

                                                <?php endif; ?>
                                            </select>
                                    </div>
                                </div>
                            </div>
                            <h5 class="card-title">Risposte</h5>


                            <div class="form-row">
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <input name="opzione1" id="" placeholder="" type="text" class="form-control" value="<?php echo e($question->opzione1); ?>"></div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <input name="opzione2" id="" placeholder=" " type="text" class="form-control"  value="<?php echo e($question->opzione2); ?> "></div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <input name="opzione3" id="" placeholder=" " type="text" class="form-control"  value="<?php echo e($question->opzione3); ?> "></div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <input name="opzione4" id="" placeholder=" " type="text" class="form-control"  value="<?php echo e($question->opzione4); ?>" ></div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <input name="opzione5" id="" placeholder=" " type="text" class="form-control"  value="<?php echo e($question->opzione5); ?>" ></div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <input name="opzione6" id="" placeholder=" " type="text" class="form-control"  value="<?php echo e($question->opzione6); ?>" ></div>
                                </div>
                            </div>

                            

                            <button type="submit" class="mt-2 btn btn-primary">Salva</button>
                        </form>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>
                    <div class="card-body"><h5 class="card-title">Domanda 1</h5>
                        <form method="POST" action="<?php echo e(route('questions.store')); ?>">

                            <?php echo csrf_field(); ?>
                            <input name="survey_id" id=""  type="hidden" class="form-control" value=" <?php echo e($survey->id); ?>">
                            <div class="form-row">
                                <div class="col-md-4">
                                    <div class="position-relative form-group"><label for="" class="">Titolo</label>
                                        <input name="titolo" id="" placeholder="" type="text" class="form-control"></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group"><label for="" class="">Descrizione</label>
                                        <input name="descrizione" id="" placeholder=" " type="text" class="form-control"></div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <label for="examplePassword"
                                            class="">Tipo risposta</label>
                                            <select class="form-control kt-select2 select2" id="kt_select2_1" name="tipo">

                                                <option value="checkbox">risposta multipla</option>
                                                <option value="radiobutton">risposta singola</option>


                                            </select>
                                    </div>
                                </div>
                            </div>
                            <h5 class="card-title">Risposte</h5>


                            <div class="form-row">
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <input name="opzione1" id="" placeholder="" type="text" class="form-control"></div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <input name="opzione2" id="" placeholder=" " type="text" class="form-control"></div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <input name="opzione3" id="" placeholder=" " type="text" class="form-control"></div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <input name="opzione4" id="" placeholder=" " type="text" class="form-control"></div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <input name="opzione5" id="" placeholder=" " type="text" class="form-control"></div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group">
                                        <input name="opzione6" id="" placeholder=" " type="text" class="form-control"></div>
                                </div>
                            </div>

                            

                            <button type="submit" class="mt-2 btn btn-primary">Salva</button>
                        </form>
                    </div>


                </div>
            </div>
        </div>
       
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODE\Survey\resources\views/admin/survey/create.blade.php ENDPATH**/ ?>