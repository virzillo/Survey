<?php $__env->startSection('content'); ?>
<div class="app-main__outer">
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="pe-7s-car icon-gradient bg-mean-fruit">
                        </i>
                    </div>
                    <div> <?php echo e($page_title); ?>

                        <div class="page-title-subheading"><?php echo e($page_description); ?> </div>
                    </div>
                </div>
                <div class="page-title-actions">

                </div>
            </div>
        </div>
        

        <div class="row">
            <div class="col-lg-12">
                <div class="main-card mb-3 card">
                    <div class="card-body"><h5 class="card-title">Anagrafica</h5>
                        <form method="POST" action="<?php echo e(route('anagrafica.update', $anagrafica->id)); ?>">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <input name="user_id" id="user_id"  type="hidden" class="form-control" value=" <?php echo e(Auth::user()->id); ?>">

                            <div class="form-row">
                                <div class="col-md-4">
                                    <div class="position-relative form-group"><label for="" class="">Nominativo struttura</label>
                                        <input name="nominativo_struttura" id="nominativo_struttura" placeholder="" type="text" class="form-control" value="<?php echo e($anagrafica->nominativo_struttura); ?>" required></div>
                                </div>
                                <div class="col-md-4">
                                    <div class="position-relative form-group"><label for="" class="">Interlocutore</label>
                                        <input name="interlocutore" id="interlocutore" placeholder="inserisci nome e cognome" type="text" class="form-control" value="<?php echo e($anagrafica->interlocutore); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group"><label for="" class="">Percentuale Cessione</label>
                                        <select name="percentuale_cessione" id="percentuale_cessione" class="form-control" required>
                                            <option value="<?php echo e($anagrafica->percentuale_cessione); ?>"><?php echo e($anagrafica->percentuale_cessione); ?></option>

                                            <option value="1-5%">1-5%</option>
                                            <option value="6-10%">6-10%</option>
                                            <option value="11-20%">11-20%</option>
                                            <option value=">20%">>20%</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="position-relative form-group"><label for="exampleSelect" class="">Potenziale struttura</label>
                                        <select name="potenziale_struttura" id="otenziale_struttura" class="form-control" required>
                                            <option value="<?php echo e($anagrafica->potenziale_struttura); ?>"><?php echo e($anagrafica->potenziale_struttura); ?></option>

                                            <option value="A">A</option>
                                            <option value="B">B</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-md-3">
                                    <div class="position-relative form-group"><label for="exampleSelect" class="">Specializzazione</label>
                                        <select name="specializzazione" id="specializzazione" class="form-control" required>
                                            <option value="<?php echo e($anagrafica->specializzazione); ?>"><?php echo e($anagrafica->specializzazione); ?></option>

                                            <option value="ANESTESIA">ANESTESIA</option>
                                            <option value="CHIRURGIA">CHIRURGIA</option>
                                            <option value="ORTOPEDIA">ORTOPEDIA</option>
                                            <option value="FISIOTERAPIA">FISIOTERAPIA</option>
                                            <option value="MEDICINA">MEDICINA</option>
                                            <option value="INTERNA">INTERNA</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="position-relative form-group"><label for="exampleSelect" class="">Profilo interlocutore</label>
                                        <select name="profilo" id="profilo" class="form-control" required>
                                            <option value="<?php echo e($anagrafica->profilo); ?>"><?php echo e($anagrafica->profilo); ?></option>

                                            <option value="BUSINESS">BUSINESS</option>
                                            <option value="CLIENTE">CLIENTE</option>
                                            <option value="SCIENZA">SCIENZA</option>
                                            <option value="PAZIENTE">PAZIENTE</option>
                                            <option value="IMMAGINE">IMMAGINE</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="position-relative form-group"><label for="exampleSelect" class="">Mezzi diagnostici a disp.</label>
                                        <select name="mezzi_diagnostici" id="mezzi_diagnostici" class="form-control" required>
                                            <option value="<?php echo e($anagrafica->mezzi_diagnostici); ?>"><?php echo e($anagrafica->mezzi_diagnostici); ?></option>

                                            <option value="RX">RX</option>
                                            <option value="TAC">TAC</option>
                                            <option value="RM">RM</option>
                                            <option value="ARTROSCOPIA">ARTROSCOPIA</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="position-relative form-group"><label for="exampleSelect" class="">Assegna survey disp.</label>
                                        <select name="survey_id" id="survey_id" class="form-control" required>
                                            <option value="<?php echo e($anagrafica->survey_id); ?>"><?php echo e($anagrafica->survey->titolo); ?></option>
                                            <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($survey->id); ?>"><?php echo e($survey->titolo); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="mt-2 btn btn-primary">Modifica</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8">
                <div class="main-card mb-3 card ">
                    <div class="card-body">
                        <h5 class="card-title">Survey</h5>
                        
                            <div id="accordion" class="accordion-wrapper mb-3">
                               <?php
                                $i=0;
                                $n=0;
                                $b=0;
                                ?>
                            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $i++;
                                $n++;
                                ?>

                                <div class="card">
                                    <div id="heading<?php echo e($i); ?>" class="card-header">
                                        <button type="button" data-toggle="collapse" data-target="#collapse<?php echo e($i); ?>1" aria-expanded="false" aria-controls="collapse<?php echo e($i); ?>" class="text-left m-0 p-0 btn btn-link btn-block collapsed">
                                            <h5 class="m-0 p-0">Domanda <?php echo e($i); ?></h5>
                                        </button>
                                    </div>
                                    <div data-parent="#accordion" id="collapse<?php echo e($i); ?>1" aria-labelledby="heading<?php echo e($i); ?>" class="collapse" style="">
                                        <div class="card-body">
                                            <form method="POST" action="<?php echo e(route('answer.store')); ?>" >
                                                <?php echo csrf_field(); ?>
                                                <input name="survey_id" id="survey_id"  type="hidden" class="form-control" value=" <?php echo e($survey->id); ?>">
                                                <input name="question_id" id="question_id"  type="hidden" class="form-control" value=" <?php echo e($question->id); ?>">
                                                <input name="anagrafica_id" id="anagrafica_id"  type="hidden" class="form-control" value=" <?php echo e($anagrafica->id); ?>">

                                                <div class="form-row">
                                                    <div class="col-md-12">
                                                        <div class="position-relative form-group"><label for="" class="">Titolo: <?php echo e($question->titolo); ?></label>
                                                            <input name="titolo" id="" placeholder=""  type="hidden" class="form-control" value="<?php echo e($question->titolo); ?>" readonly></div>
                                                    </div>
                                                </div>
                                                <div class="form-row">

                                                    <div class="col-md-12">
                                                        <div class="position-relative form-group"><label for="" class="">Suggerimento: <?php echo e($question->descrizione); ?></label>
                                                            <input name="descrizione" id="" placeholder=" "  type="hidden"  class="form-control" value="<?php echo e($question->descrizione); ?>" readonly></div>
                                                    </div>

                                                </div>
                                                <h5 class="card-title">Risposte</h5>


                                                <div class="form-row">
                                                    <?php if($question->tipo=='radiobutton'): ?>
                                                    <div class="position-relative form-group">
                                                        <div>
                                                            <?php if(isset($question->answers[($anagrafica->id)-1])): ?>
                                                            <?php $rispx=$question->answers[($anagrafica->id)-1] ; ?>
                                                            <?php endif; ?>

                                                            <?php $__currentLoopData = $question->opzione; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(isset($rispx->risposte)): ?>
                                                            <div class="custom-radio custom-control custom-control-inline">
                                                                <input type="radio" id="risposte<?php echo e($n); ?>" name="risposte"
                                                                class="custom-control-input" <?php echo e($rispx->risposte === $item ? "checked" : ""); ?>

                                                                value="<?php echo e($item); ?>">
                                                                <label class="custom-control-label" for="risposte<?php echo e($n); ?>"><?php echo e($item); ?></label><br>
                                                                </div>
                                                                <?php $n++; ?>
                                                            <?php else: ?>
                                                            <div class="custom-radio custom-control custom-control-inline">
                                                                <input type="radio" id="risposte<?php echo e($n); ?>" name="risposte"
                                                                class="custom-control-input"
                                                                value="<?php echo e($item); ?>">
                                                                <label class="custom-control-label" for="risposte<?php echo e($n); ?>"><?php echo e($item); ?></label><br>
                                                                </div>
                                                                <?php $n++; ?>
                                                            <?php endif; ?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </div>
                                                    </div>
                                                    
                                                    <?php else: ?>
                                                    <div class="position-relative form-group">
                                                        <div>
                                                            <?php if(isset($question->answers[($anagrafica->id)-1])): ?>
                                                            <?php $rispx=$question->answers[($anagrafica->id)-1] ; ?>
                                                            <?php echo e($rispx=$question->answers[($anagrafica->id)-1]); ?>


                                                            <?php endif; ?>
                                                        <?php $__currentLoopData = $question->opzione; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(isset($rispx->risposte[$key])): ?>
                                                            <div class="custom-checkbox custom-control custom-control-inline">
                                                                <input type="checkbox" id="risposte<?php echo e($n); ?>" name="risposte[]"
                                                                 class="custom-control-input"  <?php echo e($rispx->risposte[$key] === $item ? "checked" : ""); ?>

                                                                 value="<?php echo e($item); ?>">
                                                                <label class="custom-control-label" for="risposte<?php echo e($n); ?>" ><?php echo e($item); ?></label>
                                                            </div>
                                                            <?php $n++; ?>
                                                            <?php else: ?>
                                                            <div class="custom-checkbox custom-control custom-control-inline">
                                                                <input type="checkbox" id="risposte<?php echo e($n); ?>" name="risposte[]"
                                                                 class="custom-control-input"
                                                                 value="<?php echo e($item); ?>">
                                                                <label class="custom-control-label" for="risposte<?php echo e($n); ?>" ><?php echo e($item); ?></label>
                                                            </div>
                                                            <?php $n++; ?>
                                                        <?php endif; ?>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>


                                                    
                                                </div>
                                                <?php if(isset($question->answers[($anagrafica->id)-1])): ?>
                                                <button type="submit" class="mt-2 btn btn-primary" disabled>Salva</button>

                                                <?php else: ?>
                                                <button type="submit" class="mt-2 btn btn-primary">Salva</button>

                                                <?php endif; ?>
                                            </form>
                                        </div>
                                    </div>
                                </div>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>
                        

                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="main-card mb-3 card">
                    <div class="card-body"><h5 class="card-title">Note</h5>
                        <form method="POST" action="<?php echo e(route('anagrafica.update', $anagrafica->id)); ?>">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <input name="user_id" id="user_id"  type="hidden" class="form-control" value=" <?php echo e(Auth::user()->id); ?>">

                                <div class="position-relative form-group">
                                    <textarea name="note" id="note" class="form-control"><?php echo e($anagrafica->note); ?></textarea>
                                </div>

                            <div class="position-relative form-group">
                                <label for="exampleSelect" class="">Avanzamento</label>
                                <select name="avanzamento" id="avanzamento" class="form-control" required>

                                    <option value="in corso">In corso</option>
                                    <option value="concluso">Concluso</option>
                                </select>
                            </div>
                            <button type="submit" class="mt-2 btn btn-primary">Salva</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
       
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODE\Survey\resources\views/agent/anagrafica/edit.blade.php ENDPATH**/ ?>