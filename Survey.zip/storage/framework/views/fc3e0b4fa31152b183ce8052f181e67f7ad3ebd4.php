<?php $__env->startSection('content'); ?>
<div class="app-main__outer">
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="pe-7s-car icon-gradient bg-mean-fruit">
                        </i>
                    </div>
                    <div> <?php echo e($page_title); ?>

                        <div class="page-title-subheading"><?php echo e($page_description); ?> </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="main-card mb-3 card">
                    <div class="card-body"><h5 class="card-title">Elenco Anagrafiche</h5>
                        <div class="table-responsive">
                            <table class="mb-0 table table-sm">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nome Agente</th>
                                        <th>Survey</th>
                                        <th>Nome struttura</th>
                                        <th>Interlocutore</th>
                                        <th>Stato</th>
                                        <th>Avanzamento</th>

                                        <th>Azioni</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $anagrafiche; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anagrafica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($anagrafica->id); ?></th>
                                            <th ><?php echo e($anagrafica->user->name); ?></th>
                                            <th ><?php echo e($anagrafica->survey->titolo); ?></th>
                                            <td><?php echo e($anagrafica->nominativo_struttura); ?></td>
                                            <td><?php echo e($anagrafica->interlocutore); ?></td>

                                            <td><?php echo e($anagrafica->stato); ?></td>
                                            <td><?php echo e($anagrafica->avanzamento); ?></td>

                                            <td class="warning" >
                                                <form action="<?php echo e(route('anagrafica.destroy', $anagrafica->id)); ?>" method="POST"
                                                    id="form-delete">

                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <a href="<?php echo e(route('anagrafica.edit', $anagrafica->id )); ?>"
                                                        class="btn btn-icon btn-light btn-hover-primary btn-sm"
                                                        title="Visualizza">
                                                        <span class="svg-icon svg-icon-md">
                                                            <i class="fa fa-cog icon-gradient bg-mean-fruit"> </i>
                                                        </span>
                                                    </a>
                                                    <a href="<?php echo e(route('answer.risposte', $anagrafica->id )); ?>"
                                                        class="btn btn-icon btn-light btn-hover-primary btn-sm"
                                                        title="Avvia">
                                                        <span class="svg-icon svg-icon-md">
                                                            <i class="fa fa-file-archive icon-gradient bg-happy-itmeo"> </i>
                                                        </span>
                                                    </a>
                                                    <button type="button"
                                                        class="btn btn-icon btn-light btn-hover-danger btn-sm "
                                                        id="confirm-delete" onclick="ConfirmDelete()">
                                                        <span class="svg-icon svg-icon-md">
                                                            <i class="fa fa-archive icon-gradient bg-sunny-morning"> </i>
                                                        </span>
                                                    </button>

                                                </form>

                                            </td>

                                            

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            </table>
                        </div>


                    </div>
                </div>
            </div>
        </div>
       
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODE\Survey\resources\views/admin/anagrafiche/index.blade.php ENDPATH**/ ?>