<?php $__env->startSection('content'); ?>
<div class="app-main__outer">
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    <div class="page-title-icon">
                        <i class="pe-7s-car icon-gradient bg-mean-fruit">
                        </i>
                    </div>
                    <div> <?php echo e($page_title); ?>

                        <div class="page-title-subheading"><?php echo e($page_description); ?> </div>
                    </div>
                </div>
                <div class="page-title-actions">
                    
                    
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-xl-4">
                <div class="card mb-3 widget-content bg-midnight-bloom">
                    <div class="widget-content-wrapper text-white">
                        <div class="widget-content-left">
                            <div class="widget-heading">Survey</div>
                            <div class="widget-subheading">Da completare</div>
                        </div>
                        <div class="widget-content-right">
                            <div class="widget-numbers text-white"><span><?php echo e(($survey->limite)-$totale); ?></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="main-card mb-3 card">
                <div class="card-body"><h5 class="card-title">Crea Anagrafica</h5>
                    <form method="POST" action="<?php echo e(route('anagrafica.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <input name="user_id" id="user_id"  type="hidden" class="form-control" value=" <?php echo e(Auth::user()->id); ?>">

                        <div class="form-row">
                            <div class="col-md-4">
                                <div class="position-relative form-group"><label for="" class="">Nominativo struttura</label>
                                    <input name="nominativo_struttura" id="nominativo_struttura" placeholder="" type="text" class="form-control" required></div>
                            </div>
                            <div class="col-md-4">
                                <div class="position-relative form-group"><label for="" class="">Interlocutore</label>
                                    <input name="interlocutore" id="interlocutore" placeholder="inserisci nome e cognome" type="text" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="position-relative form-group"><label for="" class="">Percentuale Cessione</label>
                                    <select name="percentuale_cessione" id="percentuale_cessione" class="form-control" required>
                                        <option value="1-5%">1-5%</option>
                                        <option value="6-10%">6-10%</option>
                                        <option value="11-20%">11-20%</option>
                                        <option value=">20%">>20%</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="position-relative form-group"><label for="exampleSelect" class="">Potenziale struttura</label>
                                    <select name="potenziale_struttura" id="otenziale_struttura" class="form-control" required>
                                        <option value="A">A</option>
                                        <option value="B">B</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-md-3">
                                <div class="position-relative form-group"><label for="exampleSelect" class="">Specializzazione</label>
                                    <select name="specializzazione" id="specializzazione" class="form-control" required>
                                        <option value="ANESTESIA">ANESTESIA</option>
                                        <option value="CHIRURGIA">CHIRURGIA</option>
                                        <option value="ORTOPEDIA">ORTOPEDIA</option>
                                        <option value="FISIOTERAPIA">FISIOTERAPIA</option>
                                        <option value="MEDICINA">MEDICINA</option>
                                        <option value="INTERNA">INTERNA</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="position-relative form-group"><label for="exampleSelect" class="">Profilo interlocutore</label>
                                    <select name="profilo" id="profilo" class="form-control" required>
                                        <option value="BUSINESS">BUSINESS</option>
                                        <option value="CLIENTE">CLIENTE</option>
                                        <option value="SCIENZA">SCIENZA</option>
                                        <option value="PAZIENTE">PAZIENTE</option>
                                        <option value="IMMAGINE">IMMAGINE</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="position-relative form-group"><label for="exampleSelect" class="">Mezzi diagnostici a disp.</label>
                                    <select name="mezzi_diagnostici" id="mezzi_diagnostici" class="form-control" required>
                                        <option value="RX">RX</option>
                                        <option value="TAC">TAC</option>
                                        <option value="RM">RM</option>
                                        <option value="ARTROSCOPIA">ARTROSCOPIA</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="position-relative form-group"><label for="exampleSelect" class="">Assegna survey disp.</label>
                                    <select name="survey_id" id="survey_id" class="form-control" required>
                                        <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($survey->id); ?>"><?php echo e($survey->titolo); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="mt-2 btn btn-primary">Crea</button>
                    </form>
                </div>
            </div>
                <div class="main-card mb-3 card">
                    <div class="card-body"><h5 class="card-title">Elenco Anagrafiche</h5>
                        <div class="table-responsive">
                            <table class="mb-0 table table-sm">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nome struttura</th>
                                        <th>Interlocutore</th>
                                        <th>Stato</th>
                                        <th>Avanzamento</th>

                                        <th>Azioni</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $anagrafiche; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anagrafica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($anagrafica->id); ?></th>
                                            <td><?php echo e($anagrafica->nominativo_struttura); ?></td>
                                            <td><?php echo e($anagrafica->interlocutore); ?></td>

                                            <td><?php echo e($anagrafica->stato); ?></td>
                                            <td><?php echo e($anagrafica->avanzamento); ?></td>

                                            <td class="warning" >
                                                <form action="<?php echo e(route('anagrafica.destroy', $anagrafica->id)); ?>" method="POST"
                                                    id="form-delete">

                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <a href="<?php echo e(route('anagrafica.edit', $anagrafica->id )); ?>"
                                                        class="btn btn-icon btn-light btn-hover-primary btn-sm"
                                                        title="Visualizza">
                                                        <span class="svg-icon svg-icon-md">
                                                            <i class="fa fa-cog icon-gradient bg-mean-fruit"> </i>
                                                        </span>
                                                    </a>
                                                    <a href="<?php echo e(route('anagrafica.create', $anagrafica->id )); ?>"
                                                        class="btn btn-icon btn-light btn-hover-primary btn-sm"
                                                        title="Avvia">
                                                        <span class="svg-icon svg-icon-md">
                                                            <i class="fa fa-file-archive icon-gradient bg-happy-itmeo"> </i>
                                                        </span>
                                                    </a>
                                                    <button type="button"
                                                        class="btn btn-icon btn-light btn-hover-danger btn-sm "
                                                        id="confirm-delete" onclick="ConfirmDelete()">
                                                        <span class="svg-icon svg-icon-md">
                                                            <i class="fa fa-archive icon-gradient bg-sunny-morning"> </i>
                                                        </span>
                                                    </button>

                                                </form>

                                            </td>

                                            

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            </table>
                        </div>


                    </div>
                </div>
            </div>
        </div>
       
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODE\Survey\resources\views/agent/anagrafica/index.blade.php ENDPATH**/ ?>